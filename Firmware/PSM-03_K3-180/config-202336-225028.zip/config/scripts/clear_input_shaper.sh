#!/bin/bash
rm /tmp/*.csv;
rm ~/klipper_config/input_shaper_results/*.png;